import json
import logging
import threading
import pickle
import re
from abc import ABC, ABCMeta, abstractmethod
from datetime import datetime, timedelta
from urllib import request
from urllib.error import HTTPError

from csdr.module import PickleModule
from owrx.aprs import AprsParser, AprsLocation
from owrx.config import Config
from owrx.map import Map, LatLngLocation
from owrx.bands import Bandplan

logger = logging.getLogger(__name__)


class Enricher(ABC):
    def __init__(self, parser):
        self.parser = parser

    @abstractmethod
    def enrich(self, meta, callback):
        pass


class RadioIDCache(object):
    sharedInstance = None

    @staticmethod
    def getSharedInstance():
        if RadioIDCache.sharedInstance is None:
            RadioIDCache.sharedInstance = RadioIDCache()
        return RadioIDCache.sharedInstance

    def __init__(self):
        self.cache = {}
        self.cacheTimeout = timedelta(seconds=86400)

    def isValid(self, mode, radio_id):
        key = self.__key(mode, radio_id)
        if key not in self.cache:
            return False
        entry = self.cache[key]
        return entry["timestamp"] + self.cacheTimeout > datetime.now()

    def __key(self, mode, radio_id):
        return "{}-{}".format(mode, radio_id)

    def put(self, mode, radio_id, value):
        self.cache[self.__key(mode, radio_id)] = {"timestamp": datetime.now(), "data": value}

    def get(self, mode, radio_id):
        if not self.isValid(mode, radio_id):
            return None
        return self.cache[self.__key(mode, radio_id)]["data"]


class RadioIDEnricher(Enricher):
    def __init__(self, mode, parser):
        super().__init__(parser)
        self.mode = mode
        self.threads = {}
        self.callbacks = {}

    def _fillCache(self, id):
        data = self._downloadRadioIdData(id)
        RadioIDCache.getSharedInstance().put(self.mode, id, data)
        if id in self.callbacks:
            while self.callbacks[id]:
                self.callbacks[id].pop()(data)
            del self.callbacks[id]
        del self.threads[id]

    def _downloadRadioIdData(self, id):
        try:
            logger.debug("requesting radioid metadata for mode=%s and id=%s", self.mode, id)
            res = request.urlopen("https://www.radioid.net/api/{0}/user/?id={1}".format(self.mode, id), timeout=30)
            if res.status != 200:
                logger.warning("radioid API returned error %i for mode=%s and id=%s", res.status, self.mode, id)
                return None
            data = json.loads(res.read().decode("utf-8"))
            if "count" in data and data["count"] > 0 and "results" in data:
                for item in data["results"]:
                    if "radio_id" in item and item["radio_id"] == id:
                        return item
        except json.JSONDecodeError:
            logger.warning("unable to parse radioid response JSON")
        except HTTPError as e:
            logger.warning("radioid responded with error: %s", str(e))

        return None

    def enrich(self, meta, callback):
        config_key = "digital_voice_{}_id_lookup".format(self.mode)
        if not Config.get()[config_key]:
            return meta
        if "source" not in meta:
            return meta
        id = int(meta["source"])
        cache = RadioIDCache.getSharedInstance()
        if not cache.isValid(self.mode, id):
            if id not in self.threads:
                self.threads[id] = threading.Thread(target=self._fillCache, args=[id], daemon=True)
                self.threads[id].start()
            if id not in self.callbacks:
                self.callbacks[id] = []

            def onFinish(data):
                if data is not None:
                    meta["additional"] = data
                callback(meta)

            self.callbacks[id].append(onFinish)
            return meta
        data = cache.get(self.mode, id)
        if data is not None:
            meta["additional"] = data
        return meta


class DigihamEnricher(Enricher, metaclass=ABCMeta):
    def parseCoordinate(self, meta, mode):
        for key in ["lat", "lon"]:
            if key in meta:
                meta[key] = float(meta[key])
        callsign = self.getCallsign(meta)
        if callsign is not None and "lat" in meta and "lon" in meta:
            loc = LatLngLocation(meta["lat"], meta["lon"])
            Map.getSharedInstance().updateLocation(callsign, loc, mode, self.parser.getBand())
        return meta

    @abstractmethod
    def getCallsign(self, meta):
        pass


class DmrEnricher(DigihamEnricher, RadioIDEnricher):
    # callsign must be uppercase alphanumeric and at the beginning
    # if there's anything after the callsign, it must be separated by a whitespace
    talkerAliasRegex = re.compile("^([A-Z0-9]+)(\\s.*)?$")

    def __init__(self, parser):
        super().__init__("dmr", parser)

    def getCallsign(self, meta):
        # there's no explicit callsign data in dmr, so we can only rely on one of the following:
        # a) a callsign provided by a radioid lookup
        if "additional" in meta and "callsign" in meta["additional"]:
            return meta["additional"]["callsign"]
        # b) a callsign in the talker alias
        if "talkeralias" in meta:
            matches = DmrEnricher.talkerAliasRegex.match(meta["talkeralias"])
            if matches:
                return matches.group(1)

    def enrich(self, meta, callback):
        def asyncParse(meta):
            self.parseCoordinate(meta, "DMR")
            callback(meta)
        meta = super().enrich(meta, asyncParse)
        meta = self.parseCoordinate(meta, "DMR")
        return meta


class YsfMetaEnricher(DigihamEnricher):
    def getCallsign(self, meta):
        if "source" in meta:
            return meta["source"]

    def enrich(self, meta, callback):
        meta = self.parseCoordinate(meta, "YSF")
        return meta


class P25MetaEnricher(DigihamEnricher):
    algorithms = {
        0x00: "ACCORDION-3",
        0x01: "BATON-AUTO-EVEN",
        0x02: "FIREFLY",
        0x03: "MAYFLY",
        0x04: "SAVILLE",
        0x05: "PADSTONE",
        0x41: "BATON-AUTO-ODD",
        0x80: "CLEARTEXT",
        0x81: "DES-OFB",
        0x82: "3DES-2K",
        0x83: "3DES-3K",
        0x84: "AES-256",
        0x86: "AES-128",
        0x88: "AES-CBC",
        0x89: "AES-128-OFB",
        0x9F: "DES-XL",
        0xA0: "DVI-XL",
        0xA1: "DVP-XL",
        0xA2: "DVP-SPFL",
        0xA3: "HAYSTACK",
        0xAA: "ADP-40-RC4",
        0xAB: "CFX-256",
        0xAF: "AES-256-GCM",
        0xB0: "DVP",
    }

    manufacturers = {
        0x00: "Generic pre-2001",
        0x01: "Generic post-2001",
        0x09: "Aselsan",
        0x10: "Relm / BK Radio",
        0x18: "EADS Public Safety",
        0x20: "Cycomm",
        0x28: "Efratom Time and Frequency Products",
        0x30: "Com-Net Ericsson",
        0x34: "Etherstack",
        0x38: "Datron",
        0x40: "Icom",
        0x48: "Garmin",
        0x50: "GTE",
        0x55: "IFR Systems",
        0x5A: "INIT Innovations in Transportation",
        0x60: "GEC-Marconi",
        0x64: "Harris",
        0x68: "Kenwood Communications",
        0x70: "Glenayre Electronics",
        0x74: "Japan Radio",
        0x78: "Kokusai",
        0x7C: "Maxon",
        0x80: "Midland",
        0x86: "Daniels Electronics",
        0x90: "Motorola",
        0xA0: "Thales",
        0xA4: "M/A-COM",
        0xB0: "Raytheon",
        0xC0: "SEA",
        0xC8: "Securicor",
        0xD0: "ADI",
        0xD8: "Tait Electronics",
        0xE0: "Teletec",
        0xF0: "Transcrypt International",
        0xF8: "Vertex Standard",
        0xFC: "Zetron",
    }

    def getCallsign(self, meta):
        if "source" in meta:
            return meta["source"]

    def enrich(self, meta, callback):
        meta = self.parseCoordinate(meta, "P25")
        if "algid" in meta:
            algid = int(meta["algid"])
            if algid in self.algorithms:
                meta["algorithm"] = self.algorithms[algid]
        if "mfid" in meta:
            mfid = int(meta["mfid"])
            if mfid in self.manufacturers:
                meta["manufacturer"] = self.manufacturers[mfid]
        return meta


class DStarEnricher(DigihamEnricher):
    def getCallsign(self, meta):
        if "ourcall" in meta:
            return meta["ourcall"]

    def enrich(self, meta, callback):
        meta = self.parseCoordinate(meta, "D-Star")
        meta = self.parseDprs(meta)
        return meta

    def parseDprs(self, meta):
        if "dprs" in meta:
            try:
                # we can send the DPRS stuff through our APRS parser to extract the information
                # TODO: only third-party parsing accepts this format right now
                parser = AprsParser()
                dprsData = parser.parseThirdpartyAprsData(meta["dprs"])
                if "data" in dprsData:
                    data = dprsData["data"]
                    if "lat" in data and "lon" in data:
                        # TODO: we could actually get the symbols from the parsed APRS data and show that on the meta panel
                        meta["lat"] = data["lat"]
                        meta["lon"] = data["lon"]

                        if "ourcall" in meta:
                            # send location info to map as well (it will show up with the correct symbol there!)
                            loc = AprsLocation(data)
                            Map.getSharedInstance().updateLocation(meta["ourcall"], loc, "DPRS", self.parser.getBand())
            except Exception:
                logger.exception("Error while parsing DPRS data")

        return meta


class MetaParser(PickleModule):
    def __init__(self):
        self.enrichers = {
            "DMR": DmrEnricher(self),
            "YSF": YsfMetaEnricher(self),
            "P25": P25MetaEnricher(self),
            "DSTAR": DStarEnricher(self),
            "NXDN": RadioIDEnricher("nxdn", self),
        }
        self.currentMetaData = None
        self.band = None
        super().__init__()

    def process(self, meta):
        self.currentMetaData = None
        if "protocol" in meta:
            protocol = meta["protocol"]
            if protocol in self.enrichers:
                self.currentMetaData = meta = self.enrichers[protocol].enrich(meta, self.receive)
        return meta

    def receive(self, meta):
        # we may have moved on in the meantime
        if meta is not self.currentMetaData:
            return
        self.writer.write(pickle.dumps(meta))

    def setDialFrequency(self, freq):
        self.band = Bandplan.getSharedInstance().findBand(freq)

    def getBand(self):
        return self.band
