import threading
from owrx.source import SdrSourceEventClient, SdrSourceState, SdrClientClass
from owrx.sdr import SdrService
from owrx.bands import Bandplan
from owrx.config import Config
from owrx.source.resampler import Resampler
from owrx.property import PropertyLayer, PropertyDeleted
from owrx.service.schedule import ServiceScheduler
from owrx.service.chain import ServiceDemodulatorChain
from owrx.modes import Modes, DigitalMode
from typing import Union, Optional
from csdr.chain.demodulator import BaseDemodulatorChain, ServiceDemodulator, DialFrequencyReceiver, FixedAudioRateChain
from pycsdr.modules import Buffer

import sys
import logging

logger = logging.getLogger(__name__)


class ServiceHandler(SdrSourceEventClient):
    def __init__(self, source):
        self.lock = threading.RLock()
        self.services = []
        self.resamplers = []
        self.source = source
        self.startupTimer = None
        self.activitySub = None
        self.running = False
        props = self.source.getProps()
        self.enabledSub = props.wireProperty("services", self._receiveEvent)
        self.decodersSub = None
        # need to call _start() manually if property is not set since the default is True, but the initial call is only
        # made if the property is present
        if "services" not in props:
            self._start()

    def _receiveEvent(self, state):
        # deletion means fall back to default, which is True
        if state is PropertyDeleted:
            state = True
        if self.running == state:
            return
        if state:
            self._start()
        else:
            self._stop()

    def _start(self):
        self.running = True
        self.source.addClient(self)
        props = self.source.getProps()
        self.activitySub = props.filter("center_freq", "samp_rate").wire(self.onFrequencyChange)
        self.decodersSub = Config.get().wireProperty("services_decoders", self.onFrequencyChange)
        if self.source.isAvailable():
            self._scheduleServiceStartup()

    def _stop(self):
        if self.activitySub is not None:
            self.activitySub.cancel()
            self.activitySub = None
        if self.decodersSub is not None:
            self.decodersSub.cancel()
            self.decodersSub = None
        self._cancelStartupTimer()
        self.source.removeClient(self)
        self.stopServices()
        self.running = False

    def getClientClass(self) -> SdrClientClass:
        return SdrClientClass.INACTIVE

    def onStateChange(self, state: SdrSourceState):
        if state is SdrSourceState.RUNNING:
            self._scheduleServiceStartup()
        elif state is SdrSourceState.STOPPING:
            logger.debug("sdr source becoming unavailable; stopping services.")
            self.stopServices()

    def onFail(self):
        logger.debug("sdr source failed; stopping services.")
        self.stopServices()

    def onShutdown(self):
        logger.debug("sdr source is shutting down; shutting down service handler, too.")
        self.shutdown()

    def onEnable(self):
        self._scheduleServiceStartup()

    def isSupported(self, mode):
        configured = Config.get()["services_decoders"]
        available = [m.modulation for m in Modes.getAvailableServices()]
        return mode in configured and mode in available

    def shutdown(self):
        self._stop()
        if self.enabledSub is not None:
            self.enabledSub.cancel()
            self.enabledSub = None

    def stopServices(self):
        with self.lock:
            resamplers = self.resamplers
            services = self.services
            self.resamplers = []
            self.services = []

        for service in services:
            service.stop()
        services.clear()

        # resamplers are stopped after the services since they must not be
        # shutdown as long as the services are still running
        for resampler in resamplers:
            resampler.stop()
        resamplers.clear()

    def onFrequencyChange(self, changes):
        self.stopServices()
        if not self.source.isAvailable():
            return
        self._scheduleServiceStartup()

    def _cancelStartupTimer(self):
        if self.startupTimer:
            self.startupTimer.cancel()
            self.startupTimer = None

    def _scheduleServiceStartup(self):
        self._cancelStartupTimer()
        self.startupTimer = threading.Timer(10, self.updateServices)
        self.startupTimer.start()

    def updateServices(self):
        def addService(dial, source):
            try:
                service = self.setupService(dial, source)
                self.services.append(service)
            except Exception:
                logger.exception("Error setting up service {mode} on frequency {frequency}".format(**dial))

        with self.lock:
            logger.debug("re-scheduling services due to sdr changes")
            self.stopServices()
            if not self.source.isAvailable():
                logger.debug("sdr source is unavailable")
                return
            cf = self.source.getProps()["center_freq"]
            sr = self.source.getProps()["samp_rate"]
            srh = sr / 2
            frequency_range = (cf - srh, cf + srh)

            dials = [
                dial
                for dial in Bandplan.getSharedInstance().collectDialFrequencies(frequency_range)
                if self.isSupported(dial["mode"])
            ]

            if not dials:
                logger.debug("no services available")
                return

            groups = self.optimizeResampling(dials, sr)
            if groups is None:
                for dial in dials:
                    addService(dial, self.source)
            else:
                for group in groups:
                    if len(group) > 1:
                        cf = self.get_center_frequency(group)
                        bw = self.get_bandwidth(group)
                        logger.debug("setting up resampler on center frequency: {0}, bandwidth: {1}".format(cf, bw))
                        resampler_props = PropertyLayer(center_freq=cf, samp_rate=bw)
                        resampler = Resampler(resampler_props, self.source)

                        for dial in group:
                            addService(dial, resampler)

                        # resamplers go onto a sseparate list
                        self.resamplers.append(resampler)
                    else:
                        dial = group[0]
                        addService(dial, self.source)

    def get_min_max(self, group):
        minFreq = sys.maxsize
        maxFreq = 0

        for dial in group:
            mode = Modes.findByModulation(dial["mode"])
            if "underlying" in dial:
                mode = mode.for_underlying(dial["underlying"])
            bandwidth = mode.get_bandwidth()
            minFreq = min(minFreq, dial["frequency"] - bandwidth / 2)
            maxFreq = max(maxFreq, dial["frequency"] + bandwidth / 2)

        return minFreq, maxFreq

    def get_center_frequency(self, group):
        minFreq, maxFreq = self.get_min_max(group)
        return (minFreq + maxFreq) / 2

    def get_bandwidth(self, group):
        minFreq, maxFreq = self.get_min_max(group)
        # minimum bandwidth for a resampler: 25kHz
        return max((maxFreq - minFreq) * 1.15, 25000)

    def optimizeResampling(self, freqs, bandwidth):
        freqs = sorted(freqs, key=lambda f: f["frequency"])
        distances = [
            {
                "frequency": freqs[i]["frequency"],
                "distance": freqs[i + 1]["frequency"] - freqs[i]["frequency"],
            }
            for i in range(0, len(freqs) - 1)
        ]

        distances = [d for d in distances if d["distance"] > 0]

        distances = sorted(distances, key=lambda f: f["distance"], reverse=True)

        def calculate_usage(num_splits):
            splits = sorted([f["frequency"] for f in distances[0:num_splits]])
            previous = 0
            groups = []
            for split in splits:
                groups.append([f for f in freqs if previous < f["frequency"] <= split])
                previous = split
            groups.append([f for f in freqs if previous < f["frequency"]])

            def get_total_bandwidth(group):
                if len(group) > 1:
                    return bandwidth + len(group) * self.get_bandwidth(group)
                else:
                    return bandwidth

            total_bandwidth = sum([get_total_bandwidth(group) for group in groups])
            return {
                "num_splits": num_splits,
                "total_bandwidth": total_bandwidth,
                "groups": groups,
            }

        usages = [calculate_usage(i) for i in range(0, len(freqs))]
        # another possible outcome might be that it's best not to resample at all. this is a special case.
        usages += [
            {
                "num_splits": None,
                "total_bandwidth": bandwidth * len(freqs),
                "groups": [freqs],
            }
        ]
        results = sorted(usages, key=lambda f: f["total_bandwidth"])

        for r in results:
            logger.debug("splits: {0}, total: {1}".format(r["num_splits"], r["total_bandwidth"]))

        best = results[0]
        if best["num_splits"] is None:
            return None
        return best["groups"]

    def setupService(self, dial, source):
        logger.debug("setting up service {mode} on frequency {frequency}".format(**dial))

        modeObject = Modes.findByModulation(dial["mode"])
        if not isinstance(modeObject, DigitalMode):
            logger.warning("mode is not a digimode: %s", dial["mode"])
            return None

        if "underlying" in dial:
            modeObject = modeObject.for_underlying(dial["underlying"])

        demod2 = self._getSecondaryDemodulator(modeObject.modulation)
        if isinstance(demod2, FixedAudioRateChain):
            demod = self._getDemodulator(modeObject.get_modulation(), demod2.getFixedAudioRate())
        else:
            demod = self._getDemodulator(modeObject.get_modulation())
        if isinstance(demod2, DialFrequencyReceiver):
            demod2.setDialFrequency(dial["frequency"])

        center_freq = source.getProps()["center_freq"]
        sampleRate = source.getProps()["samp_rate"]

        chain = ServiceDemodulatorChain(demod, demod2, sampleRate, dial["frequency"] - center_freq)
        bandpass = modeObject.get_bandpass()
        if bandpass:
            chain.setBandPass(bandpass.low_cut, bandpass.high_cut)
        else:
            chain.setBandPass(None, None)
        chain.setReader(source.getBuffer().getReader())
        chain.setFrequency(dial["frequency"])
        chain.setMode(dial["mode"])

        # dummy buffer, we don't use the output right now
        buffer = Buffer(chain.getOutputFormat())
        chain.setWriter(buffer)
        return chain

    # TODO move this elsewhere
    def _getDemodulator(self, demod: Union[str, BaseDemodulatorChain], sampleRate: int = 48000):
        if isinstance(demod, BaseDemodulatorChain):
            return demod
        # TODO: move this to Modes
        if demod == "nfm":
            from csdr.chain.analog import NFm
            return NFm(sampleRate)
        elif demod == "am":
            from csdr.chain.analog import Am
            return Am()
        elif demod == "sam":
            from csdr.chain.analog import SAm
            return SAm()
        elif demod in ["usb", "lsb", "cw"]:
            from csdr.chain.analog import Ssb
            return Ssb()
        elif demod == "empty":
            from csdr.chain.analog import Empty
            return Empty()

    # TODO move this elsewhere
    def _getSecondaryDemodulator(self, mod) -> Optional[ServiceDemodulator]:
        if isinstance(mod, ServiceDemodulatorChain):
            return mod
        if mod in ["ft8", "wspr", "jt65", "jt9", "ft4", "fst4", "fst4w", "q65"]:
            from csdr.chain.digimodes import AudioChopperDemodulator
            from owrx.wsjt import WsjtParser
            return AudioChopperDemodulator(mod, WsjtParser())
        elif mod == "msk144":
            from csdr.chain.digimodes import Msk144Demodulator
            return Msk144Demodulator()
        elif mod == "js8":
            from csdr.chain.digimodes import AudioChopperDemodulator
            from owrx.js8 import Js8Parser
            return AudioChopperDemodulator(mod, Js8Parser())
        elif mod == "packet":
            from csdr.chain.digimodes import PacketDemodulator
            return PacketDemodulator(service=True)
        elif mod == "ais":
            from csdr.chain.digimodes import PacketDemodulator
            return PacketDemodulator(service=True, ais=True)
        elif mod == "sstv":
            from csdr.chain.digimodes import SstvDemodulator
            return SstvDemodulator(service=True)
        elif mod == "fax":
            from csdr.chain.digimodes import FaxDemodulator
            return FaxDemodulator(service=True)
        elif mod == "navtex":
            from csdr.chain.digimodes import NavtexDemodulator
            return NavtexDemodulator(100, 170 + 40, service=True)
        elif mod == "dsc":
            from csdr.chain.digimodes import DscDemodulator
            return DscDemodulator(100, 170 + 40, service=True)
        elif mod == "page":
            from csdr.chain.toolbox import PageDemodulator
            return PageDemodulator(service=True)
        elif mod == "eas":
            from csdr.chain.toolbox import EasDemodulator
            return EasDemodulator(service=True)
        elif mod == "ism":
            from csdr.chain.toolbox import IsmDemodulator
            return IsmDemodulator(250000, service=True)
        elif mod == "wmbus":
            from csdr.chain.toolbox import IsmDemodulator
            return IsmDemodulator(1200000, service=True)
        elif mod == "hfdl":
            from csdr.chain.aircraft import HfdlDemodulator
            return HfdlDemodulator(service=True)
        elif mod == "vdl2":
            from csdr.chain.aircraft import Vdl2Demodulator
            return Vdl2Demodulator(service=True)
        elif mod == "acars":
            from csdr.chain.aircraft import AcarsDemodulator
            return AcarsDemodulator(service=True)
        elif mod == "adsb":
            from csdr.chain.aircraft import AdsbDemodulator
            return AdsbDemodulator(service=True)
        elif mod == "uat":
            from csdr.chain.aircraft import UatDemodulator
            return UatDemodulator(service=True)
        elif mod == "audio":
            from csdr.chain.toolbox import AudioRecorder
            return AudioRecorder(service=True)
        elif mod == "speech":
            from csdr.chain.toolbox import AudioTranscriber
            return AudioTranscriber(service=True)
        elif mod == "cwskimmer":
            from csdr.chain.toolbox import CwSkimmerDemodulator
            return CwSkimmerDemodulator(service=True)
        elif mod == "rttyskimmer":
            from csdr.chain.toolbox import RttySkimmerDemodulator
            return RttySkimmerDemodulator(service=True)
        elif mod == "sonde-rs41":
            from csdr.chain.sonde import Rs41Demodulator
            return Rs41Demodulator(service=True)
        elif mod == "sonde-dfm9":
            from csdr.chain.sonde import Dfm9Demodulator
            return Dfm9Demodulator(service=True)
        elif mod == "sonde-dfm17":
            from csdr.chain.sonde import Dfm17Demodulator
            return Dfm17Demodulator(service=True)
        elif mod == "sonde-mts01":
            from csdr.chain.sonde import Mts01Demodulator
            return Mts01Demodulator(service=True)
        elif mod == "sonde-m10":
            from csdr.chain.sonde import M10Demodulator
            return M10Demodulator(service=True)
        elif mod == "sonde-m20":
            from csdr.chain.sonde import M20Demodulator
            return M20Demodulator(service=True)
        elif mod == "meteor-lrpt":
            from csdr.chain.satellite import MeteorLrptDemodulator
            return MeteorLrptDemodulator(service=True)
        elif mod == "elektro-lrit":
            from csdr.chain.satellite import ElektroLritDemodulator
            return ElektroLritDemodulator(service=True)
        elif mod == "lora-wan":
            from csdr.chain.lora import LoraWanDemodulator
            return LoraWanDemodulator(service=True)
        elif mod == "lora-aprs":
            from csdr.chain.lora import LoraAprsDemodulator
            return LoraAprsDemodulator(service=True)
        elif mod == "lora-fanet":
            from csdr.chain.lora import LoraFanetDemodulator
            return LoraFanetDemodulator(service=True)
        elif mod == "meshtastic":
            from csdr.chain.lora import MeshtasticDemodulator
            return MeshtasticDemodulator(service=True)
        elif mod == "meshcore":
            from csdr.chain.lora import MeshcoreDemodulator
            return MeshcoreDemodulator(service=True)
        elif mod == "meshcom":
            from csdr.chain.lora import MeshComDemodulator
            return MeshComDemodulator(service=True)
        # NOAA-15 satellite has been retired, not operational
        #elif mod == "noaa-apt-15":
        #    from csdr.chain.satellite import NoaaAptDemodulator
        #    return NoaaAptDemodulator(satellite=15, service=True)
        # NOAA-19 satellite has been retired, not operational
        #elif mod == "noaa-apt-19":
        #    from csdr.chain.satellite import NoaaAptDemodulator
        #    return NoaaAptDemodulator(satellite=19, service=True)

        raise ValueError("unsupported service modulation: {}".format(mod))


class Services(object):
    handlers = {}
    schedulers = {}

    @staticmethod
    def start():
        config = Config.get()
        config.wireProperty("services_enabled", Services._receiveEnabledEvent)
        activeSources = SdrService.getActiveSources()
        activeSources.wire(Services._receiveDeviceEvent)
        for key, source in activeSources.items():
            Services.schedulers[key] = ServiceScheduler(source)

    @staticmethod
    def _receiveEnabledEvent(state):
        if state:
            for key, source in SdrService.getActiveSources().__dict__().items():
                Services.handlers[key] = ServiceHandler(source)
        else:
            for handler in list(Services.handlers.values()):
                handler.shutdown()
            Services.handlers = {}

    @staticmethod
    def _receiveDeviceEvent(changes):
        for key, source in changes.items():
            if source is PropertyDeleted:
                if key in Services.handlers:
                    handler = Services.handlers[key]
                    del Services.handlers[key]
                    handler.shutdown()
                if key in Services.schedulers:
                    scheduler = Services.schedulers[key]
                    del Services.schedulers[key]
                    scheduler.shutdown()
            else:
                Services.schedulers[key] = ServiceScheduler(source)
                if Config.get()["services_enabled"]:
                    Services.handlers[key] = ServiceHandler(source)

    @staticmethod
    def stop():
        for handler in list(Services.handlers.values()):
            handler.shutdown()
        Services.handlers = {}
        for scheduler in list(Services.schedulers.values()):
            scheduler.shutdown()
        Services.schedulers = {}

    @staticmethod
    def listAll():
        result = []
        for handler in list(Services.handlers.values()):
            sdr  = handler.source.getName()
            band = handler.source.getProfileName()
            for service in handler.services:
                if isinstance(service, ServiceDemodulatorChain):
                    freq = service.getFrequency()
                    mode = service.getMode()
                    if freq and mode:
                        result.append({
                            "sdr"  : sdr,
                            "band" : band,
                            "freq" : freq,
                            "mode" : mode
                        })
        return result
