#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "CodecServer::codecserver" for configuration "None"
set_property(TARGET CodecServer::codecserver APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(CodecServer::codecserver PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libcodecserver.so.0.2.0"
  IMPORTED_SONAME_NONE "libcodecserver.so.0.2.0"
  )

list(APPEND _IMPORT_CHECK_TARGETS CodecServer::codecserver )
list(APPEND _IMPORT_CHECK_FILES_FOR_CodecServer::codecserver "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libcodecserver.so.0.2.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
