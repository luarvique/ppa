#pragma once

#include "decoder.hpp"

namespace Digiham {

    namespace Ysf {

        class Decoder: public Digiham::Decoder {
            public:
                Decoder();
        };

    }

}