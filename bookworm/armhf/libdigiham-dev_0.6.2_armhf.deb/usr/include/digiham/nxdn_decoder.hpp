#pragma once

#include "decoder.hpp"

namespace Digiham {

    namespace Nxdn {

        class Decoder: public Digiham::Decoder {
            public:
                Decoder();
        };


    }

}