#pragma once

#include <string>

namespace Csdr::Eti {

    extern const std::string version;

}