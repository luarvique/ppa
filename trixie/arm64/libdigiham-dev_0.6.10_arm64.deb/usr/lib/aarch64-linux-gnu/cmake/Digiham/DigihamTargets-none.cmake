#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Digiham::digiham" for configuration "None"
set_property(TARGET Digiham::digiham APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Digiham::digiham PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libdigiham.so.0.6.2"
  IMPORTED_SONAME_NONE "libdigiham.so.0.6.2"
  )

list(APPEND _cmake_import_check_targets Digiham::digiham )
list(APPEND _cmake_import_check_files_for_Digiham::digiham "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libdigiham.so.0.6.2" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
