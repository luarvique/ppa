#pragma once

#include <string>

namespace Digiham {

    extern const std::string version;

}