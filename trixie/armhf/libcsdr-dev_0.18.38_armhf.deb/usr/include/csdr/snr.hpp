/*
This software is part of libcsdr, a set of simple DSP routines for
Software Defined Radio.

Copyright (c) 2022-2025 Marat Fayzullin <luarvique@gmail.com>
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the copyright holder nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL ANDRAS RETZLER BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

#include <functional>
#include "module.hpp"
#include <fftw3.h>

namespace Csdr {

    template <typename T>
    class Snr: public Module<T, T> {
        public:
            Snr(size_t length, size_t fftSize = 256, std::function<void(float)> callback = 0);
            ~Snr() override;

            size_t getLength();
            bool canProcess() override;
            void process() override;

        protected:
            // to be overridden by the squelch implementation
            virtual void forwardData(T* input, float snr);

        private:
            size_t length;
            size_t fftSize;
            std::function<void(float)> callback;

            fftwf_complex* fftInput;
            fftwf_complex* fftOutput;
            fftwf_plan fftPlan;
            float *hamWindow;
    };

    template <typename T>
    class SnrSquelch: public Snr<T> {
        public:
            SnrSquelch(size_t length, size_t fftSize = 256, size_t hangLength = 0, size_t flushLength = 0, std::function<void(float)> callback = 0);
            void setSquelch(float squelchLevel);

        protected:
            void forwardData(T* input, float snr) override;

        private:
            std::function<void(float)> callback;
            size_t length;
            size_t hangLength;
            size_t flushLength;

            float squelchLevel = 0.0f;
            size_t hangCounter = 0;
            size_t flushCounter = 0;
    };
}
