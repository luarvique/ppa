from distutils.version import StrictVersion

_versionstring = "0.1.1"
strictversion = StrictVersion(_versionstring)
