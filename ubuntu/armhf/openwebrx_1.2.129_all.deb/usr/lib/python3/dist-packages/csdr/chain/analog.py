from csdr.chain.demodulator import BaseDemodulatorChain, FixedIfSampleRateChain, HdAudio, \
    HdStereo, FixedAudioRateChain, DeemphasisTauChain, MetaProvider, RdsChain
from pycsdr.modules import AmDemod, DcBlock, FmDemod, BCFmDemod, Limit, NfmDeemphasis, \
    Agc, Afc, WfmDeemphasis, FractionalDecimator, StereoFractionalDecimator, RealPart, \
    Writer, Buffer
from pycsdr.types import Format, AgcProfile
from csdr.chain.toolbox import RdsDemodulator
from typing import Optional
from owrx.feature import FeatureDetector


class Am(BaseDemodulatorChain):
    def __init__(self, agcProfile: AgcProfile = AgcProfile.SLOW):
        agc = Agc(Format.FLOAT)
        agc.setProfile(agcProfile)
        agc.setInitialGain(200)
        workers = [
            AmDemod(),
            DcBlock(),
            agc,
        ]
        super().__init__(workers)


class NFm(BaseDemodulatorChain):
    def __init__(self, sampleRate: int, agcProfile: AgcProfile = AgcProfile.SLOW):
        self.sampleRate = sampleRate
        agc = Agc(Format.FLOAT)
        agc.setProfile(agcProfile)
        agc.setMaxGain(3)
        workers = [
            FmDemod(),
            Limit(Format.FLOAT),
            NfmDeemphasis(sampleRate),
            agc,
        ]
        super().__init__(workers)

    def setSampleRate(self, sampleRate: int) -> None:
        if sampleRate == self.sampleRate:
            return
        self.sampleRate = sampleRate
        self.replace(2, NfmDeemphasis(sampleRate))


class BaseWFm(BaseDemodulatorChain, FixedIfSampleRateChain, DeemphasisTauChain, MetaProvider, RdsChain):
    def __init__(self, rdsRbds: bool, workers):
        self.rdsRbds = rdsRbds
        # this buffer is used to tap into the raw audio stream for redsea RDS decoding
        self.metaTapBuffer = Buffer(Format.FLOAT)
        self.metaChain = None
        self.metaWriter = None
        super().__init__(workers)

    def getFixedIfSampleRate(self):
        return self.getFixedAudioRate()

    def getFixedAudioRate(self) -> int:
        return 192000

    def _connect(self, w1, w2, buffer: Optional[Buffer] = None) -> None:
        if w1 is self.limit:
            buffer = self.metaTapBuffer
        super()._connect(w1, w2, buffer)

    def setMetaWriter(self, writer: Writer) -> None:
        if not FeatureDetector().is_available("rds"):
            return
        if self.metaChain is None:
            self.metaChain = RdsDemodulator(self.getFixedIfSampleRate(), self.rdsRbds)
            self.metaChain.setReader(self.metaTapBuffer.getReader())
        self.metaWriter = writer
        self.metaChain.setWriter(self.metaWriter)

    def stop(self):
        super().stop()
        if self.metaChain is not None:
            self.metaChain.stop()
            self.metaChain = None
            self.metaWriter = None

    def setRdsRbds(self, rdsRbds: bool) -> None:
        self.rdsRbds = rdsRbds
        if self.metaChain is not None:
            self.metaChain.stop()
            self.metaChain = RdsDemodulator(self.getFixedIfSampleRate(), self.rdsRbds)
            self.metaChain.setReader(self.metaTapBuffer.getReader())
            self.metaChain.setWriter(self.metaWriter)


class WFm(BaseWFm, HdAudio):
    def __init__(self, sampleRate: int, tau: float, rdsRbds: bool):
        self.sampleRate = sampleRate
        self.tau = tau
        self.limit = Limit(Format.FLOAT)
        workers = [
            FmDemod(),
            self.limit,
            self._createDecimator(),
            WfmDeemphasis(self.sampleRate, self.tau),
        ]
        super().__init__(rdsRbds, workers)

    def setDeemphasisTau(self, tau: float) -> None:
        if tau == self.tau:
            return
        self.tau = tau
        self.replace(3, WfmDeemphasis(self.sampleRate, self.tau))

    def setSampleRate(self, sampleRate: int) -> None:
        if sampleRate == self.sampleRate:
            return
        self.sampleRate = sampleRate
        self.replace(2, self._createDecimator())
        self.replace(3, WfmDeemphasis(self.sampleRate, self.tau))

    def _createDecimator(self):
        return FractionalDecimator(
            Format.FLOAT,
            self.getFixedIfSampleRate() / self.sampleRate,
            prefilter=True
        )


class BCFm(BaseWFm, HdStereo):
    def __init__(self, sampleRate: int, tau: float, rdsRbds: bool):
        self.sampleRate = sampleRate
        self.tau = tau
        self.limit = Limit(Format.FLOAT)
        workers = [
            BCFmDemod(),
            self.limit,
            self._createDecimator(),
        ]
        super().__init__(rdsRbds, workers)

    def setDeemphasisTau(self, tau: float) -> None:
        if tau == self.tau:
            return
        self.tau = tau
        self.replace(2, self._createDecimator())

    def setSampleRate(self, sampleRate: int) -> None:
        if sampleRate == self.sampleRate:
            return
        self.sampleRate = sampleRate
        self.replace(2, self._createDecimator())

    def _createDecimator(self):
        mpxRate = self.getFixedIfSampleRate()
        return StereoFractionalDecimator(
            Format.FLOAT,
            mpxRate,
            mpxRate / self.sampleRate,
            self.tau,
            numPolyPoints=12,
            prefilter=False
        )


class Ssb(BaseDemodulatorChain):
    def __init__(self, agcProfile: AgcProfile = AgcProfile.FAST):
        agc = Agc(Format.FLOAT)
        agc.setProfile(agcProfile)
        workers = [
            RealPart(),
            agc,
        ]
        super().__init__(workers)


class Empty(BaseDemodulatorChain):
    def __init__(self):
        super().__init__([])

    def getOutputFormat(self) -> Format:
        return Format.FLOAT

    def setWriter(self, writer):
        pass


class SAm(BaseDemodulatorChain):
    def __init__(self, sampleRate: int, agcProfile: AgcProfile = AgcProfile.SLOW):
        agc = Agc(Format.FLOAT)
        agc.setProfile(agcProfile)
        agc.setInitialGain(200)
        workers = [
            Afc(sampleRate),
            RealPart(),
            DcBlock(),
            agc,
        ]
        super().__init__(workers)


class IqStream(BaseDemodulatorChain, FixedAudioRateChain, HdStereo):
    def __init__(self, sampleRate: int = 48000):
        self.sampleRate = sampleRate
        workers = [
            Agc(Format.COMPLEX_FLOAT),
        ]
        super().__init__(workers)

    def getFixedAudioRate(self) -> int:
        return self.sampleRate
