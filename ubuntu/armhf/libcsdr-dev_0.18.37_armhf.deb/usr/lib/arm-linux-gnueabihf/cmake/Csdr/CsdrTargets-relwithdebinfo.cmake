#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Csdr::csdr++" for configuration "RelWithDebInfo"
set_property(TARGET Csdr::csdr++ APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Csdr::csdr++ PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libcsdr++.so.0.18.2"
  IMPORTED_SONAME_RELWITHDEBINFO "libcsdr++.so.0.18"
  )

list(APPEND _IMPORT_CHECK_TARGETS Csdr::csdr++ )
list(APPEND _IMPORT_CHECK_FILES_FOR_Csdr::csdr++ "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libcsdr++.so.0.18.2" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
